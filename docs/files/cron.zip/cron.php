<?php

$ch = curl_init('YOUR-SUPPORTBOARD-URL/include/api.php');
$parameters = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'Support Board',
        CURLOPT_POST => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_POSTFIELDS => http_build_query(['token' => 'YOUR-TOKEN', 'function' => 'email-piping'])
];
curl_setopt_array($ch, $parameters);
$response = curl_exec($ch);
curl_close($ch);
die($response);

?>

 